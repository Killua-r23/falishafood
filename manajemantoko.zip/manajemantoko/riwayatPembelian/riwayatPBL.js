// Ambil elemen-elemen penting
const tabelBody = document.getElementById("tabelBody");
const searchInput = document.getElementById("searchInput");
const petugasSpan = document.getElementById("petugas");
const menuBtn = document.getElementById("menuBtn");
const toggleTheme = document.getElementById("toggleTheme");
const popup = document.getElementById("popup");
const popupText = document.getElementById("popupText");

// Ambil data user login dari localStorage
const userLogin = JSON.parse(localStorage.getItem("userLogin")) || {};
petugasSpan.textContent = `👤 ${userLogin.nama || "Guest"}`;

// Arahkan kembali ke menu
menuBtn.addEventListener("click", () => {
  window.location.href = "../menu.html";
});

// Ganti tema
toggleTheme.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});

// Ambil data Pembelian dari localStorage
let dataPembelian = JSON.parse(localStorage.getItem("riwayatPembelian")) || [];

// Tampilkan data ke tabel
function tampilkanData(data) {
  tabelBody.innerHTML = "";

  if (!data.length) {
    popup.classList.add("show");
    setTimeout(() => popup.classList.remove("show"), 3000);
    return;
  }

  data.forEach((item, index) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${item.kode}</td>
      <td>${item.tanggal}</td>
      <td>${item.Supplier}</td>
      <td>${item.alamat}</td>
      <td>${item.petugas}</td>
      <td>${item.items ? item.items.length : 0}</td>
      <td>
        <button onclick="lihatDetail(${index})">Detail</button>
        <button onclick="hapusTransaksi(${index})">Hapus</button>
      </td>
    `;
    tabelBody.appendChild(tr);
  });
}

// Fitur search
searchInput.addEventListener("input", () => {
  const keyword = searchInput.value.toLowerCase();
  const hasil = dataPembelian.filter(p =>
    p.kode.toLowerCase().includes(keyword) ||
    p.tanggal.toLowerCase().includes(keyword) ||
    p.Supplier.toLowerCase().includes(keyword)
  );
  tampilkanData(hasil);
});

// Fungsi popup
function tampilkanPopup(pesan) {
  const popup = document.getElementById("popup");
  const popupText = document.getElementById("popupText");

  if (popup && popupText) {
    popupText.textContent = pesan;
    popup.classList.add("show");

    setTimeout(() => {
      popup.classList.remove("show");
    }, 3000);
  } else {
    console.error("Elemen popup tidak ditemukan");
  }
}

// Fitur filter tanggal
window.filterTanggal = function () {
  const tglAwal = document.getElementById("tanggalAwal").value;
  const tglAkhir = document.getElementById("tanggalAkhir").value;

  if (!tglAwal || !tglAkhir) {
    tampilkanPopup("Silakan isi kedua tanggal terlebih dahulu.");
    return;
  }

  const hasil = dataPembelian.filter(p => {
    return p.tanggal >= tglAwal && p.tanggal <= tglAkhir;
  });

  if (hasil.length === 0) {
    tampilkanPopup("Tidak ada transaksi pada rentang tanggal tersebut.");
  }


  tampilkanData(hasil);
};

// Fitur reset filter
window.resetFilter = function () {
  document.getElementById("tanggalAwal").value = "";
  document.getElementById("tanggalAkhir").value = "";
  searchInput.value = "";
  tampilkanData(dataPembelian);
};

// Lihat detail transaksi
window.lihatDetail = function (index) {
  const data = dataPembelian[index];
  if (!data || !data.items) return alert("Data tidak tersedia.");

  const detailContainer = document.getElementById("detailContainer");
  detailContainer.innerHTML = `
    <p><strong>Kode:</strong> ${data.kode}</p>
    <p><strong>Tanggal:</strong> ${data.tanggal}</p>
    <p><strong>Supplier:</strong> ${data.Supplier}</p>
    <p><strong>Alamat:</strong> ${data.alamat}</p>
    <p><strong>Petugas:</strong> ${data.petugas}</p>
    <hr>
    <table>
      <thead>
        <tr>
          <th>Barang</th>
          <th>Harga</th>
          <th>Jumlah</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        ${data.items.map(item => `
          <tr>
            <td>${item.nama}</td>
            <td>${item.harga}</td>
            <td>${item.jumlah}</td>
            <td>${item.harga * item.jumlah}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
  document.getElementById("popupDetail").classList.remove("hidden");
};

// Tutup popup detail
window.tutupPopup = function () {
  document.getElementById("popupDetail").classList.add("hidden");
};

// Hapus transaksi per item
window.hapusTransaksi = function (index) {
  if (!confirm("Yakin ingin menghapus transaksi ini?")) return;
  dataPembelian.splice(index, 1);
  localStorage.setItem("riwayatPembelian", JSON.stringify(dataPembelian));
  tampilkanData(dataPembelian);
};

// Inisialisasi awal
tampilkanData(dataPembelian);
